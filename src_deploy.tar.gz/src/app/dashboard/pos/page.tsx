'use client'

import PosSystem from '@/components/PosSystem'

export default function DashboardOSPage() {
    return <PosSystem restrictedMode={false} />
}
