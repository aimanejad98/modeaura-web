'use client'

import PosSystem from '@/components/PosSystem'

export default function CashierPage() {
    return <PosSystem restrictedMode={true} />
}
